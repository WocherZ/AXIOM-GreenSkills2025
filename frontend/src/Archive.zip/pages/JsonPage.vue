<template>
  <q-page padding>
    <h3>JSON Page</h3>
    <JsonView />
  </q-page>
</template>

<script setup lang="ts">
import JsonView from 'components/JsonView.vue'

defineOptions({
  name: 'JsonPage'
})

</script>
